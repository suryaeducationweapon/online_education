import 'package:flutter/material.dart';


//downShape clip
class CurvePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    var paint = Paint();
    paint.color = Colors.orange[200];      //Colors.blue[900];
    paint.style = PaintingStyle.fill;

    var path = Path();

    path.moveTo(0, size.height *0.9890);
    path.quadraticBezierTo(size.width * 0.25, size.height * 0.445,
        size.width * 0.5, size.height * 0.6167);
    path.quadraticBezierTo(size.width * 0.80, size.height * 0.8584,
        size.width * 1.0, size.height * 0.04);
    path.lineTo(size.width, size.height);
    path.lineTo(0, size.height);

    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) {
    return true;
  }
}
class CurvePaint extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    var paint = Paint();
    paint.color = Color(0xFFFFcc99);
    paint.style = PaintingStyle.fill;

    var path = Path();



    path.moveTo(0, size.height *0.9890);
    path.quadraticBezierTo(size.width * 0.25, size.height * 0.445,
        size.width * 0.5, size.height * 0.6167);
    path.quadraticBezierTo(size.width * 0.80, size.height * 0.8584,
        size.width * 1.0, size.height * 0.04);
    path.lineTo(size.width, size.height);
    path.lineTo(0, size.height);


    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) {
    return true;
  }
}
//...............................top shape..........
class CurvePainters extends CustomPainter{
  @override
  void paint(Canvas canvas, Size size) {
    Path path = Path();
    Paint paint = Paint();

    path.lineTo(0, size.height *0.90);
    path.quadraticBezierTo(size.width*0.20, size.height*0.30, size.width*0.50, size.height*0.60);

    path.quadraticBezierTo(size.width*0.80, size.height*0.90, size.width,0);
    path.close();

    paint.color =Colors.orange[200];         //Colors.blue[900];
    canvas.drawPath(path, paint);

  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) {
    return oldDelegate != this;
  }

}
//.........
class CurvePainterss extends CustomPainter{
  @override
  void paint(Canvas canvas, Size size) {
    Path path = Path();
    Paint paint = Paint();

    path.lineTo(0, size.height *0.90);
    path.quadraticBezierTo(size.width*0.20, size.height*0.30, size.width*0.50, size.height*0.60);
    path.quadraticBezierTo(size.width*0.80, size.height*0.90, size.width,0);
    path.close();

    paint.color =Color(0xFFFFcc99);
    canvas.drawPath(path, paint);

  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) {
    return oldDelegate != this;
  }

}


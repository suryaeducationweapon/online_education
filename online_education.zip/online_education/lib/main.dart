import 'dart:async';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:online_education/screen/introslide/IntroSlider.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch:Colors.blue
      ),
      home: MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {


  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    
    Timer(Duration(seconds:3),()=>Navigator.pushAndRemoveUntil(context,MaterialPageRoute(builder: (context)=>IntroSliderScreen()), (route) => false));
    
  }
  

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      backgroundColor:Colors.white,

      body:Column(
        mainAxisAlignment:MainAxisAlignment.center,
        children: [
          Center(
            child: Container(

              child:Image.asset("assets/images/splash.png",height:500.0,
                width:400.0,),
              // child:CircularProgressIndicator()
            ),
          ),
          Container(
            child:Center(
                child: Text("Online Education",
                style:TextStyle(
                  color:Colors.orange,
                  fontSize:30,
                  fontFamily:"Barlow",
                  fontWeight:FontWeight.w900
                ),
                )
            ),
          ),
          Center(
            child: Container(
              height:70,
              width:70,
              margin:EdgeInsets.only(top:20),
              child:CircularProgressIndicator(
                backgroundColor:Colors.green,
              ),
            ),
          )
        ],
      ),

    );
  }
}

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:online_education/Quiz/home.dart';
import 'package:online_education/screen/signup/RegistrationScreen.dart';



import '../../Shapes.dart';


class LoginScreen extends StatefulWidget {
  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {

  void _CreateNewAccount(){
    Navigator.push(context, MaterialPageRoute(builder: (context)=>RegistrationScreen()));


  }

  void _gotoSignIn(){

    Navigator.push(context, MaterialPageRoute(builder: (context)=>homepage()));

  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: Colors.white,
        body:SingleChildScrollView(
          child: Column(
            crossAxisAlignment:CrossAxisAlignment.start,
            children:<Widget> [
              Stack(
                children: [
                  Container(
                    child: CustomPaint(
                      painter:CurvePainterss(),
                      child: Container(
                        height:165,
                      ),
                    ),
                  ),
                  Container(

                    child: CustomPaint(
                      painter:CurvePainters(),
                      child: Container(
                        height:150,
                      ),
                    ),
                  ),
                ],
              ),



              Container(
                margin: EdgeInsets.only(left: 40),
                child:CircleAvatar(
                  backgroundColor: Colors.white,
                  radius:80,
                    child: Image.asset("assets/images/logo.png",height:120,width:120,fit: BoxFit.cover,)),
              ),
              Stack(
                children: [
                  Container(
                    margin:EdgeInsets.only(top:1),
                    child: Column(
                      children: [
                        Container(
                          width:300,
                          decoration:BoxDecoration(
                            borderRadius: BorderRadius.only(
                              topRight: Radius.circular(30),
                              // bottomRight:Radius.circular(20)
                            ),
                            border: Border.all(
                              width: 1,
                              color: Colors.black,
                              style: BorderStyle.solid,
                            ),
                          ),
                          child:Row(
                            mainAxisAlignment:MainAxisAlignment.center,
                            children: [
                              Icon(Icons.person,size:30,color:Color(0xFFFFE0B3),),
                              Container(
                                width:220,
                                child:TextFormField(
                                  decoration:InputDecoration(
                                      hintText:"User Name"
                                  ),
                                ),
                              )
                            ],
                          ),
                        ),
                        Container(
                          margin:EdgeInsets.only(top:5),
                          width:300,
                          decoration:BoxDecoration(
                            borderRadius: BorderRadius.only(
                              //topRight: Radius.circular(20),
                                bottomRight:Radius.circular(30)
                            ),
                            border: Border.all(
                              width: 1,
                              color: Colors.black,
                              style: BorderStyle.solid,
                            ),
                          ),
                          child:Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Icons.lock,size:30,color:Color(0xFFFFE0B3),),
                              Container(
                                width:220,
                                child:TextFormField(
                                  decoration:InputDecoration(
                                    hintText:"Password",


                                  ),
                                ),
                              )
                            ],
                          ),
                        ),

                      ],
                    ),
                  ),


                  GestureDetector(
                    onTap:_gotoSignIn ,
                    child: Container(
                      margin:EdgeInsets.only(top:15,left:270),
                      child: CircleAvatar(
                          backgroundColor:Colors.orange[200],
                          radius:30,
                          child: Icon(Icons.arrow_forward_rounded,size:30,color:Colors.white,)),
                    ),
                  )
                ],
              ),


              SizedBox(height: 40,),

              GestureDetector(
                onTap:_gotoSignIn,
                child: Container(
                  height:50,
                  width: 200,
                  decoration:BoxDecoration(
                    borderRadius: BorderRadius.only(
                        topRight: Radius.circular(20),
                        bottomRight:Radius.circular(20)
                    ),
                    border: Border.all(
                      width: 1,
                      color: Colors.black,
                      style: BorderStyle.solid,
                    ),
                  ),
                  child:Container(
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Center(
                        child: Text("Sign In",textAlign:TextAlign.center,style:TextStyle(
                            color:Colors.orange[200],
                            fontSize:18,
                            fontWeight:FontWeight.w900
                        ),),
                      ),
                    ),
                  ),
                ),
              ),
//...........................curve shape..........

              Stack(
                children: [
                  Container(
                    child: CustomPaint(
                      painter:CurvePaint(),
                      child: Container(
                        height:220,
                      ),
                    ),
                  ),
                  Container(
                    child: CustomPaint(
                      painter:CurvePainter(),
                      child: Container(
                        height:230,
                      ),
                    ),
                  ),
                  Container(
                    margin:EdgeInsets.only(top:180,left:120),
                    child:GestureDetector(
                      onTap:_CreateNewAccount,
                      child: Text("Forgot ? | Create New Account",style:TextStyle(
                          color:Colors.white,
                          fontSize:18,
                          fontFamily:"Barlow",
                          fontWeight: FontWeight.w600
                      ),),
                    ),
                  )
                ],
              )


            ],
          ),
        ),
      ),
    );
  }
}

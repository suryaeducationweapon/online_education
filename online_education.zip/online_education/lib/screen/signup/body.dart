import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:dropdown_search/dropdown_search.dart';

class SignupBody extends StatefulWidget {
  @override
  _SignupBodyState createState() => _SignupBodyState();
}

class _SignupBodyState extends State<SignupBody> {
  int _value=0;
  File _image;
  final picker = ImagePicker();

  Future getImage() async {
    final pickedFile = await picker.getImage(source: ImageSource.gallery);

    setState(() {
      if (pickedFile != null) {
        _image = File(pickedFile.path);
      } else {
        print('No image selected.');
      }
    });
  }

  Widget _NameTextField(){
    return Container(
      height:50,
      margin:
      const EdgeInsets.only(left: 30.0,top:30, right: 30.0),
      decoration:BoxDecoration(
        color:Colors.white,
      ),
      child:TextFormField(
        keyboardType:TextInputType.text,
        decoration:InputDecoration(
            hintText: "Name",
            border: OutlineInputBorder(
              borderSide: new BorderSide(color: Colors.white),



            ),
        ),
        style:TextStyle(
            color:Colors.black,
            fontFamily:"Barlow",
            fontWeight:FontWeight.w400,
            fontSize:18
        ),
      ),
    );
  }
  Widget _FatherNameTextField(){
    return Container(
      height:50,
      margin:
      const EdgeInsets.only(left: 30.0,top:30, right: 30.0),
      decoration:BoxDecoration(
        color:Colors.white,
      ),
      child:TextFormField(
        keyboardType:TextInputType.text,
        decoration:InputDecoration(
          hintText: "Father Name",
          border: OutlineInputBorder(
            borderSide: new BorderSide(color: Colors.white),


          ),
        ),
        style:TextStyle(
            color:Colors.black,
            fontFamily:"Barlow",
            fontWeight:FontWeight.w400,
            fontSize:18
        ),
      ),
    );
  }


  Widget _MobileTextField(){
    return Container(
      height:50,
      margin:
      const EdgeInsets.only(left: 30.0,top:20, right: 30.0),
      color:Colors.white,
      child:TextFormField(
        keyboardType:TextInputType.text,
        decoration:InputDecoration(
            hintText: "Mobile Number",
            border: OutlineInputBorder()
        ),
        style:TextStyle(
            color:Colors.black,
            fontFamily:"Barlow",
            fontWeight:FontWeight.w400,
            fontSize:18
        ),
      ),
    );
  }
  Widget _EmailTextField(){
    return Container(
      height:50,
      margin: const EdgeInsets.only(left: 30.0,top:20, right: 30.0),
      color:Colors.white,
      child:TextFormField(
        keyboardType:TextInputType.text,
        decoration:InputDecoration(
            hintText: "Email Address",
            border: OutlineInputBorder()
        ),
        style:TextStyle(
            color:Colors.black,
            fontFamily:"Barlow",
            fontWeight:FontWeight.w400,
            fontSize:18
        ),
      ),
    );
  }
 /* Widget _QualificationTextField(){
    return Container(
      height:50,
      margin:
      const EdgeInsets.only(left: 30.0,top:20, right: 30.0),
      color:Colors.white,
      child:TextFormField(
        keyboardType:TextInputType.text,
        decoration:InputDecoration(
            hintText: "Qualification",
            border: OutlineInputBorder()
        ),
        style:TextStyle(
            color:Colors.black,
            fontFamily:"Barlow",
            fontWeight:FontWeight.w400,
            fontSize:18
        ),
      ),
    );
  }*/

  Widget _Branch(){
    return DropdownSearch<String>(
        mode: Mode.MENU,
        showSelectedItem: true,
        items: ["Computer Science & Engineering","Information Technology", "Electronic Communication", 'Chemical Engineering','Agriculture Engineering'],
        showSearchBox:true,
        showClearButton: false,
        hint: "Branch",
        popupItemDisabled: (String s) => s.startsWith('I'),
        onChanged: print,
        selectedItem: "Select Branch");

  }
  Widget _Year(){
    return DropdownSearch<String>(
        mode: Mode.MENU,
        showSelectedItem: true,
        items: ["First Year","Second Year", "Third Year", 'Fourth Year',],
        showSearchBox:true,
        showClearButton: false,
        hint: "Year",
        popupItemDisabled: (String s) => s.startsWith('I'),
        onChanged: print,
        selectedItem: "Select Year");

  }

  Widget _Text(){
    return Container(
      child:Text("Gender",
        style: TextStyle(
            color:Colors.black,
            fontSize:18,
            fontWeight:FontWeight.w600,
            fontFamily: "Barlow"
        ),
      ),

    );
  }

  Widget _Sex(){
    return Container(
      child: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Container(

          child: Row(
            mainAxisAlignment:MainAxisAlignment.spaceAround,
            children: <Widget>[
              GestureDetector(
                onTap: () => setState(() => _value = 0),
                child: Container(
                    height:40,
                    decoration:BoxDecoration(
                        color: _value == 0 ? Color(0xFFFFcc99) : Colors.transparent,
                        borderRadius:BorderRadius.only(bottomLeft:Radius.circular(10),
                            bottomRight:Radius.circular(10),topLeft:Radius.circular(10),topRight:Radius.circular(10)

                        )
                    ),

                    child:Container(
                      decoration:BoxDecoration(
                        // color:Colors.white,
                          borderRadius:BorderRadius.only(bottomLeft:Radius.circular(20),
                              bottomRight:Radius.circular(20),topLeft:Radius.circular(20),topRight:Radius.circular(20)

                          )
                      ),
                      child:Row(
                        children: [
                          new Image.asset("assets/images/worker.png",height:35,width:35,) ,
                          new Text(
                            'Male',
                            style: TextStyle(
                                color:Colors.black,
                                fontSize:18,
                                fontWeight:FontWeight.w600,
                                fontFamily: "Barlow"
                            ),
                          ),

                        ],
                      ),
                    )
                ),
              ),
              SizedBox(width: 4),
              GestureDetector(
                onTap: () => setState(() => _value = 1),
                child: Container(
                  height:40,
                  decoration:BoxDecoration(
                      color: _value == 1 ? Color(0xFFFFcc99) : Colors.transparent,
                      // color:Colors.white,
                      borderRadius:BorderRadius.only(bottomLeft:Radius.circular(10),
                          bottomRight:Radius.circular(10),topLeft:Radius.circular(10),topRight:Radius.circular(10)

                      )
                  ),
                  //  color: _value == 1 ? Colors.green : Colors.transparent,
                  child: Container(
                    decoration:BoxDecoration(
                      // color:Colors.white,
                        borderRadius:BorderRadius.only(bottomLeft:Radius.circular(20),
                            bottomRight:Radius.circular(20),topLeft:Radius.circular(20),topRight:Radius.circular(20)

                        )
                    ),
                    child:Row(
                      children: [
                        new Image.asset("assets/images/woman.png",height:35,width:35,) ,
                        new Text(
                          'Female',
                          style: TextStyle(
                              color:Colors.black,
                              fontSize:18,
                              fontWeight:FontWeight.w600,
                              fontFamily: "Barlow"
                          ),
                        ),

                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),

    );
  }


  Widget _AddressTextField(){
    return Container(
      height:80,
      margin:
      const EdgeInsets.only(left: 30.0,top:20, right: 30.0),
      color:Colors.white,
      child:TextFormField(
        keyboardType:TextInputType.text,
        maxLines:50,
        decoration:InputDecoration(
            hintText: "Address",
            border: OutlineInputBorder()
        ),
        style:TextStyle(
            color:Colors.black,
            fontFamily:"Barlow",
            fontWeight:FontWeight.w400,
            fontSize:18
        ),
      ),
    );
  }
  Widget _SaveButton(){
    return
      new Container(
        decoration:BoxDecoration(
            color:Colors.orange[200],
            borderRadius:BorderRadius.only(bottomLeft:Radius.circular(20),
                bottomRight:Radius.circular(20),topLeft:Radius.circular(20),topRight:Radius.circular(20)

            )
        ),
        width: 450.0,
        margin:
        const EdgeInsets.only(left: 40.0, top:20.0, right: 40.0),
        height: 50.0,
        child: Center(
          child: Text("Save",style: TextStyle(
              color:Colors.white,
              fontSize:20,
              fontWeight:FontWeight.w600,
              fontFamily: "Barlow"
          ),),
        ),
      );
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body:SingleChildScrollView(
        child: Column(
          children: [
            Center(
              child: Container(
                height:150,
                width: 200,
                child:Center(
                  child: Stack(
                    children: [
                      Container(
                          child:GestureDetector(
                              onTap:getImage,
                              child: CircleAvatar(
                                  radius:50,
                                  backgroundColor:Colors.orange[200],
                                  child: _image!=null? ClipRRect(
                                      borderRadius: BorderRadius.circular(50),
                                      child: Container(
                                        height:140,
                                        width: 140,
                                        child: CircleAvatar(
                                            radius:120,
                                            backgroundColor:Colors.orange[200],
                                            child: Image.file(_image,height: 160,width: 160,fit: BoxFit.cover,)
                                        ),
                                      )):
                                  Container(
                                      child: CircleAvatar(
                                          radius: 130.0,
                                          backgroundColor:Colors.orange[200],
                                          child: Padding(
                                            padding: const EdgeInsets.all(6.0),
                                            child: Image.asset("assets/images/worker.png",height:80,width: 80,fit: BoxFit.cover,color: Colors.black,),
                                          )))))
                      ),


                    ],
                  ),
                ),
              ),
            ),

            Container(
              child: Text("Upload Image Here",
                style: TextStyle(
                    color:Colors.orange[200],
                    fontSize:20,
                    fontWeight:FontWeight.w600,
                    fontFamily: "Barlow"
                ),
              ),
            ),

            Container(
              child: _NameTextField(),
            ),
            Container(
              child: _FatherNameTextField(),
            ),
            Container(
              margin:EdgeInsets.only(right:250),
              child:_Text(),
            ),
            Container(
              child: _Sex(),
            ),
            Container(
              child: _MobileTextField(),
            ),
            Container(
              child: _EmailTextField(),
            ),
           /* Container(
              child: _QualificationTextField(),
            ),*/

            Container(
              height:50,
              margin: const EdgeInsets.only(left: 30.0,top:20, right: 30.0),
              child: _Branch(),
            ),
            Container(
              height:50,
              margin: const EdgeInsets.only(left: 30.0,top:20, right: 30.0),
              child: _Year(),
            ),

            Container(
              child: _AddressTextField(),
            ),
            Container(
              child: _SaveButton(),
            )


          ],
        ),
      ),

    );
  }
}

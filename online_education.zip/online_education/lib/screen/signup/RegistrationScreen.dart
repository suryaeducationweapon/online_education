import 'package:flutter/material.dart';
import 'package:online_education/screen/login/LoginScreen.dart';



import '../../Shapes.dart';
import 'body.dart';


class RegistrationScreen extends StatefulWidget {
  @override
  _RegistrationScreenState createState() => _RegistrationScreenState();
}

class _RegistrationScreenState extends State<RegistrationScreen> {

  void _CreateNewAccount(){
 //   Navigator.push(context, MaterialPageRoute(builder: (context)=>SignupScreen()));
    // Navigator.push(context, MaterialPageRoute(builder: (context)=>RegistrationFormScreen()));


  }

  void _gotoLogin(){

      Navigator.push(context, MaterialPageRoute(builder: (context)=>LoginScreen()));

  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body:SingleChildScrollView(
          child: Column(
            crossAxisAlignment:CrossAxisAlignment.start,
            children:<Widget> [
              Stack(
                children: [
                  Container(
                    child: CustomPaint(
                      painter:CurvePainterss(),
                      child: Container(
                        height:165,
                      ),
                    ),
                  ),
                  Container(

                    child: CustomPaint(
                      painter:CurvePainters(),
                      child: Container(
                        height:150,
                      ),
                    ),
                  ),
                ],
              ),
   Container(
     height:400,
     child:SignupBody(),
)


//...........................curve shape..........

             ,
              Stack(
                children: [
                  Container(
                    child: CustomPaint(
                      painter:CurvePaint(),
                      child: Container(
                        height:220,
                      ),
                    ),
                  ),
                  Container(
                    child: CustomPaint(
                      painter:CurvePainter(),
                      child: Container(
                        height:230,
                      ),
                    ),
                  ),
                  Container(
                    margin:EdgeInsets.only(top:170,left:140),
                    child:GestureDetector(
                      onTap:_gotoLogin,
                      child:RichText(
                        text:TextSpan(
                            children:<TextSpan>[
                              TextSpan(
                                  text: "Already Register ",
                                  style:TextStyle(
                                      color:Colors.white,
                                      fontSize:18,
                                      fontWeight:FontWeight.w600
                                  )
                              ),
                              TextSpan(
                                  text: "  | ",
                                  style:TextStyle(
                                      color:Colors.black,
                                      fontSize:18,
                                      fontWeight:FontWeight.w900
                                  )
                              ),
                              TextSpan(
                                  text: " Login Here",
                                  style:TextStyle(
                                      color:Colors.white,
                                      fontSize:18,
                                      fontFamily:"Barlow",
                                      fontWeight:FontWeight.w900
                                  )
                              )
                            ]

                        ),
                      ),
                      /*Text("Already Register | Login Here",style:TextStyle(
                          color:Colors.white,
                          fontSize:18,
                        fontFamily: "Barlow",
                        fontWeight: FontWeight.w900
                      ),),*/
                    ),
                  )
                ],
              )


            ],
          ),
        ),
      ),
    );
  }
}

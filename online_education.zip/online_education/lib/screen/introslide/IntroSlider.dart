import 'package:flutter/material.dart';
import 'package:intro_slider/intro_slider.dart';
import 'package:intro_slider/slide_object.dart';
import 'package:online_education/screen/login/LoginScreen.dart';



class IntroSliderScreen extends StatefulWidget {

  @override
  _IntroSlideState createState() => _IntroSlideState();
}

class _IntroSlideState extends State<IntroSliderScreen> {

  List<Slide> slides = new List();

  Function goToTab;

  @override
  void initState() {
    super.initState();

    slides.add(
      new Slide(
          backgroundColor: Colors.orange[200],
        pathImage: "assets/images/sd1.png",
          heightImage:400,
          widthImage:300
      ),
    );
    slides.add(
      new Slide(

       backgroundColor: Colors.orange[200],
        pathImage:"assets/images/sd4.png",
        heightImage:400,
        widthImage:300
      ),
    );
    slides.add(
      new Slide(
          backgroundColor: Colors.orange[200],
          pathImage: "assets/images/splash.png",
          heightImage:400,
          widthImage:300
      ),
    );
  }

  void onDonePress() {
    // Back to the first tab
    this.goToTab(0);
    Navigator.pushAndRemoveUntil(context,MaterialPageRoute(builder: (context)=>LoginScreen()), (route) => false);

  }

  void onTabChangeCompleted(index) {
    // Index of current tab is focused
  }

  Widget renderNextBtn() {
  }

  Widget renderDoneBtn() {

  }

  Widget renderSkipBtn() {
  }

  List<Widget> renderListCustomTabs() {
    List<Widget> tabs = new List();
    for (int i = 0; i < slides.length; i++) {
      Slide currentSlide = slides[i];
      tabs.add(Container(
        width: double.infinity,
        height: double.infinity,
        child: Container(
         // margin: EdgeInsets.only(bottom: 60.0, top: 60.0),
          child: ListView(
            children: <Widget>[
              GestureDetector(
                 child: Image.asset(
                    currentSlide.backgroundImage,
                    fit: BoxFit.fill,
                  ),
              ),
            ],
          ),
        ),
      ));
    }
    return tabs;
  }

  @override
  Widget build(BuildContext context) {

    return new IntroSlider(
      // List slides
      slides: this.slides,
      // Skip button
      renderSkipBtn: this.renderSkipBtn(),
      styleNameDoneBtn:TextStyle(

      ),

      // Next button
      renderNextBtn: this.renderNextBtn(),
      styleNamePrevBtn:TextStyle(
         // color:Color(0xFFffcc33)
      ),

      // Done button
      renderDoneBtn: this.renderDoneBtn(),
      styleNameSkipBtn:TextStyle(
      ),
      onDonePress: this.onDonePress,

      refFuncGoToTab: (refFunc) {
        this.goToTab = refFunc;
      },

      // Show or hide status bar
      shouldHideStatusBar:false,
      // On tab change completed
     onTabChangeCompleted: this.onTabChangeCompleted,
    );
  }
}

package com.scriet.online_education

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
